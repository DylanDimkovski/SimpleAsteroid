#ifndef VECTOR
#define VECTOR

class Vector
{
public:
    float x;
    float y;
};

#endif