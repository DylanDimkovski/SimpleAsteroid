Assignment 1 - s3717379 - 3D Graphics

Assignment was developed and ran on Fedora 32 (Linux/Gnu). Ran out of time to test on Windows but should most likely be fine. MAKEFILE included

HOW TO RUN:

cd to project directory and type "make clean" and then type "make" in order to compile the code.
Then type ./Asteroid in order to run game.

Movement is controlled via W, A, D which represents Up, Left and Right respectively.

Mouse Left is used to Fire the bullets.

Thank you for looking at my presentation. I hope you are well

Features Implemented: 
    Screen mode
    The Arena
    Ready Player 1
    Starting Location
    Player Movement
    Hit the Wall
    Math Structs
    Code Quality
    Launch Position
    Asteroid Launch
    Asteroid / Ship Collision
    Multiple Asteroids
    Rotating Asteroids
    Shooting
    Hit Points
    Score
    Better Ship Movement

- Dylan Dimkovski