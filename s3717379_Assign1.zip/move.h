#ifndef MOVE
#define MOVE

#include <bitset>

enum { MOVE_FOREWARD, MOVE_BACK };
typedef std::bitset<2> Move;

#endif
